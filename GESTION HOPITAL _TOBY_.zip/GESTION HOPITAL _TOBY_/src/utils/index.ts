// export async function fetchToby() {
//   const res = await fetch("http://localhost:5500/toby/toby.json");

//   return res.json();
// }

// export async function getData({ param }: { param: string }) {
//   const data = await fetchToby();
//   return data.admin;
// }

import base from "./toby.json";

const data = base;

const dataAdmin = base.admin;
const dataUser = base.users;

const dataDepartement = base.departement;
const dataPatient = base.patient;
const dataPersonnel = base.personnel;
const dataService = base.service;
const dataTransfert = base.transfert;

export {
  data,
  dataAdmin,
  dataUser,
  dataDepartement,
  dataPatient,
  dataPersonnel,
  dataService,
  dataTransfert,
};
