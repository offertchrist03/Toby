function truncateString(params: string = "chose", limit: number = 3) {
  let newStr = "";
  for (let index = 0; index < limit; index++) {
    const char = params[index];
    newStr = newStr + char;
  }
  return newStr;
}

function capitalizeFirstLettre(params: string = "ceCi est Une PHRase") {
  let newStr = "";
  for (let index = 0; index < params.length; index++) {
    let char = params[index];
    if (index === 0) {
      char = char.toUpperCase();
    } else {
      char = char.toLowerCase();
    }
    newStr = newStr + char;
  }

  return newStr;
}

function minTwoNumbers(params: number = 0) {
  let res = "";
  params < 10 ? (res = "0" + params) : (res = "" + params);
  return res;
}
function stringToArray(params = "moi, moi1") {
  params = params + ",";
  let array: Array<string> = [];
  let str = "";

  const getOnStr = () => {
    for (let index = 0; index < params.length; index++) {
      const char = params[index];
      if (char !== ",") {
        str = str + char;
      } else {
        array.push(str);
        str = "";
      }
    }
  };
  getOnStr();
  return array;
}

function returnRandomItemArrays(
  params: Array<string | number> = ["a", "b", "c"],
) {
  const res = params[Math.floor(Math.random() * params.length)];
  return res;
}

function generateRandomNumbers() {
  const fuses = Math.floor(Math.random() * 999999999999999);
  return fuses;
}

function generateRandomKey(limit = 30) {
  const numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  const charLow = [
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g",
    "h",
    "i",
    "j",
    "k",
    "l",
    "m",
    "n",
    "o",
    "p",
    "q",
    "r",
    "s",
    "t",
    "u",
    "v",
    "w",
    "x",
    "y",
    "z",
  ];
  const charUpp = [
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
  ];
  const charSpe = ["#", "$", "%", "&"];

  let allChars = [...numbers, ...charLow, ...charUpp, ...charSpe];
  let key = "";

  for (let index = 0; index < limit; index++) {
    const c = returnRandomItemArrays(allChars);
    key = key + c;
  }

  return key;
}

function createArrayNumber(param: number) {
  let arrayRes = [];
  let init = 1;

  for (let index = 1; index <= param; index++) {
    arrayRes.push(init);
    init++;
  }

  return arrayRes;
}

function myTextEllipsis(
  text: string = "ceci est ma texte",
  limit: number = 11,
  ellipse: string = ".",
) {
  let newStr = "";
  if (text.length > limit) {
    for (let index = 0; index < limit; index++) {
      const char = text[index];
      newStr = newStr + char;
    }
    newStr = newStr + ellipse + ellipse + ellipse;
  } else {
    newStr = text;
  }
  return newStr;
}

function reverseMyString(params: string = "reverse") {
  let res: string = "";
  const maximums = params.length;
  for (let index = maximums - 1; index >= 0; index--) {
    const element = params[index];
    res = res + element;
  }
  return res;
}

function threesomeString(params: number = 20000000, space: string = ",") {
  let res: string = "";

  let uses: string = params + "";
  uses = reverseMyString(uses);

  for (let index = 1; index < uses.length + 1; index++) {
    let element = uses[index - 1];
    if (index % 3 === 0 && index < uses.length) {
      element = element + space;
    }
    res = res + element;
  }

  res = reverseMyString(res);

  return res;
}

const filterString = (param: string = "", strings: string = "") => {
  return param.indexOf(strings) !== -1;
};
const filterNumber = (param: number = 0, number: number = 0) => {
  return (param = number);
};

const hourToDay = (param: number): number => {
  let res = param / 24;
  return res;
};

const classNameFuseFilter = (...classes: string[]) => {
  return classes.filter(Boolean).join(" ");
};

export {
  truncateString,
  capitalizeFirstLettre,
  minTwoNumbers,
  stringToArray,
  generateRandomKey,
  generateRandomNumbers,
  returnRandomItemArrays,
  createArrayNumber,
  myTextEllipsis,
  reverseMyString,
  threesomeString,
  hourToDay,
  filterString,
  filterNumber,
  classNameFuseFilter,
};
