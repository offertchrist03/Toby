import { FormEvent } from "react";
import { reverseMyString } from "./usefullFunc";

export function rewriteStringTo(
  params: string = "/location",
  stop: string = "/",
  start: number = 1,
  startEnd: boolean = true,
) {
  let res = "";

  if (!startEnd) {
    for (let index = start; index < params.length; index++) {
      const element = params[index];
      if (index > 0 && element === stop) {
        break;
      } else {
        res = res + element;
      }
    }
  } else {
    for (let index = params.length - 1; index < params.length; index--) {
      const element = params[index];
      if (element === stop) {
        break;
      } else {
        res = res + element;
      }
    }
    res = reverseMyString(res);
  }

  return res;
}
