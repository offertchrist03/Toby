import React from "react";
import { CustomLinkProps } from "@/types";

import {
  FaAmbulance,
  FaHospital,
  FaHospitalSymbol,
  FaUserNurse,
} from "react-icons/fa";
import { FaHospitalUser } from "react-icons/fa6";
import { BiSolidDashboard } from "react-icons/bi";

export const iconsPersonnel = [
  <FaHospitalUser />,
  <FaAmbulance />,
  <FaHospitalSymbol />,
];

export const iconsAdmin = [
  <BiSolidDashboard />,
  <FaHospital />,
  <FaHospitalUser />,
  <FaUserNurse />,
  <FaAmbulance />,
  <FaHospitalSymbol />,
];

const adminAcces: CustomLinkProps[] = [
  {
    key: "page-0",
    icon: "ic0",
    title: "dashboard",
    link: "dashboard",
  },
  {
    key: "page-1",
    icon: "ic1",
    title: "departement",
    link: "departement",
  },
  {
    key: "page-2",
    icon: "ic2",
    title: "patient",
    link: "patient",
  },
  {
    key: "page-3",
    icon: "ic3",
    title: "personnel",
    link: "personnel",
  },
  {
    key: "page-4",
    icon: "ic4",
    title: "service",
    link: "service",
  },
  {
    key: "page-5",
    icon: "ic5",
    title: "transfert",
    link: "transfert",
  },
];

const personnelAcces: CustomLinkProps[] = [
  {
    key: "page-2",
    icon: "ic2",
    title: "patient",
    link: "patient",
  },
  {
    key: "page-4",
    icon: "ic4",
    title: "service",
    link: "service",
  },
  {
    key: "page-5",
    icon: "ic5",
    title: "transfert",
    link: "transfert",
  },
];

export { adminAcces, personnelAcces };
