import { Departement } from "@/components";
import React from "react";

function page() {
  return (
    <>
      <Departement />
    </>
  );
}

export default page;
