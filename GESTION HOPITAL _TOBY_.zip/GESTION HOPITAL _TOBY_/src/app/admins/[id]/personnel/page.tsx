import { Personnel } from "@/components";
import React from "react";

function page() {
  return (
    <>
      <Personnel />
    </>
  );
}

export default page;
