import { Transfert } from "@/components";
import React from "react";

function page() {
  return (
    <>
      <Transfert acces="admin" />
    </>
  );
}

export default page;
