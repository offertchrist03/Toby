import { Patient } from "@/components";
import React from "react";

function page() {
  return (
    <>
      <Patient />
    </>
  );
}

export default page;
