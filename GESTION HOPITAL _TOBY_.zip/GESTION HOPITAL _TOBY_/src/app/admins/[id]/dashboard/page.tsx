import { Dashboard } from "@/components";
import React from "react";

function page() {
  return (
    <>
      <Dashboard />
    </>
  );
}

export default page;
