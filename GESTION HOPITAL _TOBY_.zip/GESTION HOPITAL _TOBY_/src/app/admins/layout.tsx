import { PagesLayout } from "@/components";
import React from "react";

function layout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <PagesLayout access="admin">{children}</PagesLayout>
    </>
  );
}

export default layout;
