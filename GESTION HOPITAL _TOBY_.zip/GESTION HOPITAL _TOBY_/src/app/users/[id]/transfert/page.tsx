import { Transfert } from "@/components";
import React from "react";

function page() {
  return (
    <>
      <Transfert acces="personnel" />
    </>
  );
}

export default page;
