import { PagesLayout } from "@/components";
import React from "react";

function layout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <PagesLayout access="personnel">{children}</PagesLayout>
    </>
  );
}

export default layout;
