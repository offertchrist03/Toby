"use client";

import { classNameFuseFilter } from "@/functions/usefullFunc";
import { dataAdmin } from "@/utils";
import { useRouter } from "next/navigation";
import React, { FormEvent, useState } from "react";
import { FaRegUser } from "react-icons/fa";

function Home() {
  const [admin, setAdmin] = useState(true);

  const handleAdmin = () => {
    setAdmin(!admin);
  };

  const testRouter = (identifiant: string, password: string) => {
    const users = dataAdmin.filter((item) => item.name === identifiant);

    try {
      if (users.length > 0) {
        const user = users[0];
        if (user.password === password) {
          console.log("valider", "valider");
        } else {
          console.log("pas id", "pas id");
        }
      } else {
      }
    } catch (error) {
      console.log("error", error);
    }
  };

  const [value, setValue] = useState("");
  const handleChange = (e: InputEvent) => {
    const target = e.target;
    setValue(target.value);
  };

  const onSubmited = (e: FormEvent) => {
    e.preventDefault();
    const target = e.target;
    const identifiant = target[0].value;
    const password = target[1].value;
    console.log("target", identifiant, password);
    testRouter(identifiant, password);
  };

  return (
    <>
      <section className="w-full h-screen relative ">
        <div className="w-full max-w-sm h-fit absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 relative">
          <h1
            className={classNameFuseFilter(
              "w-24 h-24 text-xl font-semibold text-center mb-5 absolute rounded-full flex justify-center items-center top-0 left-1/2 -translate-y-1/2 shadow-md shadow-zinc-400 -translate-x-1/2",
              admin
                ? "bg-blue-200 hover:bg-blue-300 text-blue-700 "
                : "bg-yellow-200 hover:bg-yellow-300 text-yellow-700 ",
            )}
          >
            toby
          </h1>
          <form
            action=""
            className="w-full h-fit p-10 bg-zinc-50 rounded-xl shadow-md shadow-zinc-400 flex flex-col gap-5"
            onSubmit={onSubmited}
          >
            <div className="w-full h-2"></div>
            <div className="w-full flex flex-col">
              <label htmlFor="identifiantAuth" className="text-zinc-600">
                identifiant
              </label>
              <input
                value={value}
                onChange={handleChange}
                id="identifiantAuth"
                type="text"
                className="w-full h-fit bg-transparent pb-2 border-b-2 border-zinc-600/50 outline-none focus:border-green-600"
              />
            </div>
            <div className="w-full flex flex-col">
              <label htmlFor="passwordAuth" className="text-zinc-600">
                mot de passe
              </label>
              <input
                id="passwordAuth"
                type="password"
                className="w-full h-fit bg-transparent pb-2 border-b-2 border-zinc-600/50 outline-none focus:border-green-600"
              />
            </div>

            <div className="w-full h-fit flex justify-center">
              {/* <Link href={link}> */}
              <button
                type="submit"
                className={classNameFuseFilter(
                  "w-fit h-10 px-2 rounded-lg ",
                  admin
                    ? "bg-blue-600 hover:bg-blue-700 text-zinc-50"
                    : "bg-yellow-400 hover:bg-yellow-500 text-black",
                )}
              >
                valider
              </button>
              {/* </Link> */}
            </div>
          </form>
        </div>

        <div className="w-fit h-fit absolute bottom-12 right-12 ">
          <span className="absolute top-1/2 right-full -translate-y-1/2 -translate-x-1/3">
            {admin ? "admin" : "personnel"}
          </span>
          <button
            className={classNameFuseFilter(
              "w-16 h-16 rounded-full flex justify-center items-center text-xl ",
              admin
                ? "bg-blue-200 hover:bg-blue-300"
                : "bg-yellow-200 hover:bg-yellow-300",
            )}
            onClick={handleAdmin}
          >
            <FaRegUser />
          </button>
        </div>
      </section>
    </>
  );
}

export default Home;
