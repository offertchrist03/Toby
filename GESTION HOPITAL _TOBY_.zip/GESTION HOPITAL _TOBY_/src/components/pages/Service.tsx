"use client";

import { HeadlessTabs, Pages, ServiceForms } from "@/components";
import React, { useState } from "react";
import { FaChevronRight } from "react-icons/fa";
import { FaXmark } from "react-icons/fa6";

function Service() {
  const [formsDisplay, setFormsDisplay] = useState(false);
  const handleFormsDisplay = () => {
    setFormsDisplay(!formsDisplay);
  };
  return (
    <>
      <Pages
        headContainerClass="mb-5"
        headClass="text-blue-700 "
        head={
          <>
            total personnels : <span className="">50</span>
          </>
        }
        contents={
          <>
            <div className="w-full h-fit mb-5">
              <h5 className="text-red-600 font-semibold uppercase">
                service urgence
              </h5>
              <table className="w-full h-fit">
                <thead className="w-full h-fit">
                  <tr className="w-full h-10 underline text-zinc-700">
                    <td className="w-1/5">patient</td>
                    <td className="w-1/5">responsable</td>
                    <td className="w-1/5">sante</td>
                    <td className="w-1/5 text-center">traitement</td>
                    <td className="w-1/5"></td>
                  </tr>
                </thead>
                <tbody className="w-full h-fit">
                  <tr className="w-full h-14 border-b">
                    <td className="w-1/5">patient</td>
                    <td className="w-1/5">responsable</td>
                    <td className="w-1/5">sante</td>
                    <td className="w-1/5 text-center">traitement</td>
                    <td className="w-1/5">
                      <div className="w-full h-full flex justify-center items-start gap-5">
                        <button className="p-2 text-blue-600 hover:text-zinc-100 hover:bg-blue-600 rounded-full">
                          <FaChevronRight />
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="w-full h-fit ">
              <h5 className="text-green-600 font-semibold uppercase">
                service secours
              </h5>
              <table className="w-full h-fit">
                <thead className="w-full h-fit">
                  <tr className="w-full h-10 underline text-zinc-700">
                    <td className="w-1/5">matricule</td>
                    <td className="w-1/5">responsable</td>
                    <td className="w-1/5">marque</td>
                    <td className="w-1/5 text-center">disponible</td>
                    <td className="w-1/5"></td>
                  </tr>
                </thead>
                <tbody className="w-full h-fit">
                  <tr className="w-full h-14 border-b">
                    <td className="w-1/5">matricule</td>
                    <td className="w-1/5">responsable</td>
                    <td className="w-1/5">marque</td>
                    <td className="w-1/5 text-center">disponible</td>
                    <td className="w-1/5">
                      <div className="w-full h-full flex justify-center items-start gap-5">
                        <button
                          type="button"
                          onClick={handleFormsDisplay}
                          className="p-2 text-blue-600 hover:text-zinc-100 hover:bg-blue-600 rounded-full"
                        >
                          <FaChevronRight />
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </>
        }
        displayForm={formsDisplay}
        forms={
          <>
            {formsDisplay ? (
              <button
                type="button"
                onClick={handleFormsDisplay}
                className="w-10 h-10 absolute top-16 left-full flex justify-center items-center text-black hover:text-red-600 lg:hidden "
              >
                <FaXmark />
              </button>
            ) : (
              <></>
            )}
            <HeadlessTabs
              tabListClasse="w-full h-fit flex justify-evenly mb-3"
              tabListItemClass="w-fit h-10 px-2 outline-none hover:underline"
              tabListItemClassSelected="text-blue-700 underline"
              tabListItemClassNotSelected=""
              tabList={["details", "modification", "ajout"]}
              tabPanelsClasse="w-full h-fit p-5 bg-zinc-200 rounded-2xl shadow-md"
              tabPanelItemClass="w-full h-fit"
              tabPanels={[
                <ServiceForms news={false} readOnly={true} />,
                <ServiceForms news={false} readOnly={false} />,
                <ServiceForms news={true} readOnly={false} />,
              ]}
            />
          </>
        }
      />
    </>
  );
}

export default Service;
