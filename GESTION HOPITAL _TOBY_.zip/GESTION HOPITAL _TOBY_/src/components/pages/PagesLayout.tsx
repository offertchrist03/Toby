"use client";

import React, { useState } from "react";
import {
  adminAcces,
  iconsAdmin,
  iconsPersonnel,
  personnelAcces,
} from "@/constants";

import { FaCog } from "react-icons/fa";
import { FaBell, FaPowerOff, FaUser } from "react-icons/fa6";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { rewriteStringTo } from "@/functions";
import { classNameFuseFilter } from "@/functions/usefullFunc";
import { CustomLinkProps } from "@/types";

function PagesLayout({
  children,
  access = "personnel",
}: {
  children: React.ReactNode;
  access?: "admin" | "personnel";
}) {
  let location = usePathname();
  location = rewriteStringTo(location);

  const resAcces = () => {
    let res: CustomLinkProps[];
    access === "admin" ? (res = adminAcces) : (res = personnelAcces);
    return res;
  };

  const links = resAcces();

  const resIcons = () => {
    let res: React.ReactNode[];
    access === "admin" ? (res = iconsAdmin) : (res = iconsPersonnel);
    return res;
  };

  const icons = resIcons();

  return (
    <>
      <section className="w-full min-h-screen bg-transparent grid sm:grid-cols-[80px,1fr] xl:grid-cols-[250px,1fr] ">
        <nav className="w-full sm:max-w-[80px] xl:max-w-[250px] h-full min-h-screen max-h-screen fixed top-0 left-0">
          <div className="w-full h-full bg-blue-600 ">
            <h2 className="w-full h-20 flex justify-center items-center text-xl font-semibold">
              toby
            </h2>

            <ul className="w-full h-full px-5 absolute top-0 left-0 flex justify-center flex-col gap-5 text-zinc-50 ">
              {links.map((item, index) => (
                <li className="w-full h-fit" key={item.key}>
                  <Link
                    className={classNameFuseFilter(
                      "w-full h-8 flex items-center gap-3 relative before:w-[5px] before:h-full before:absolute before:right-0 before:top-0 before:hover:bg-zinc-100 before:rounded-full hover:opacity-100 cursor-pointer",
                      location === item.title
                        ? "opacity-100 before:bg-zinc-100 "
                        : "opacity-70 ",
                    )}
                    href={item.link}
                  >
                    <span className="w-6 flex justify-center">
                      {icons[index]}
                    </span>
                    <span className="sm:hidden xl:block">{item.title}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </nav>
        <div className="w-full min-h-screen"></div>

        <div className="w-full min-h-screen p-5 ">
          <div className="w-full h-fit mb-5 flex justify-between items-center">
            <div className="w-fit h-fit flex items-center gap-2">
              <h6 className="w-fit h-10 px-3 flex justify-center gap-2 items-center text-blue-700 bg-blue-100 rounded-3xl">
                <FaUser />
                <span className="">moi</span>
              </h6>
              <h6 className="capitalize">/{location}</h6>
            </div>
            <div className="w-fit h-fit flex gap-2">
              <button className="w-10 h-10 flex justify-center items-center hover:text-yellow-700 ">
                <FaCog />
              </button>
              <button className="w-10 h-10 flex justify-center items-center hover:text-green-600 ">
                <FaBell />
              </button>
              <button className="w-10 h-10 flex justify-center items-center hover:text-red-600 ">
                <FaPowerOff />
              </button>
            </div>
          </div>
          {children}
        </div>
      </section>
    </>
  );
}

export default PagesLayout;
