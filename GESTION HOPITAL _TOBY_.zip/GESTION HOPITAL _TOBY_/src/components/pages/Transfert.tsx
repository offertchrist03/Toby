"use client";

import { HeadlessTabs, Pages, TransfertForms } from "@/components";
import { AccesProps } from "@/types";
import React, { useState } from "react";

import { FaChevronRight } from "react-icons/fa";
import { FaXmark } from "react-icons/fa6";

function Transfert({ acces = "personnel" }: AccesProps) {
  const [formsDisplay, setFormsDisplay] = useState(false);
  const handleFormsDisplay = () => {
    setFormsDisplay(!formsDisplay);
  };
  return (
    <>
      <Pages
        headContainerClass="mb-5"
        headClass="text-blue-700 "
        head={
          <>
            total personnels : <span className="">50</span>
          </>
        }
        contents={
          <>
            <div className="w-full h-fit mb-5 flex flex-col gap-2">
              <table className="w-full h-fit">
                <thead className="w-full h-fit">
                  <tr className="w-full h-10 underline text-zinc-700">
                    <td className="w-1/5">patient</td>
                    <td className="w-1/5">responsable</td>
                    <td className="w-1/5">motif</td>
                    <td className="w-1/5 text-center">lieu</td>
                    <td className="w-[10%] text-center">acceptee</td>
                    <td className="w-[10%]"></td>
                  </tr>
                </thead>
              </table>

              <h5 className="text-green-600 h-10 font-semibold uppercase flex items-center bg-green-200 rounded-lg px-2">
                demande transfert
              </h5>
              <table className="w-full h-fit">
                <tbody className="w-full h-fit">
                  <tr className=""></tr>
                  <tr className="w-full h-14 border-b">
                    <td className="w-1/5">patient</td>
                    <td className="w-1/5">responsable</td>
                    <td className="w-1/5">motif</td>
                    <td className="w-1/5 text-center">lieu</td>
                    <td className="w-[10%] text-center">oui/non</td>
                    <td className="w-[10%]">
                      <div className="w-full h-full flex justify-center items-start gap-5">
                        <button
                          type="button"
                          onClick={handleFormsDisplay}
                          className="p-2 text-blue-600 hover:text-zinc-100 hover:bg-blue-600 rounded-full"
                        >
                          <FaChevronRight />
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>

              <h5 className="text-blue-700 h-10 font-semibold uppercase flex items-center bg-blue-200 rounded-lg px-2">
                transfert effectuee
              </h5>
              <table className="w-full h-fit">
                <tbody className="w-full h-fit">
                  <tr className=""></tr>
                  <tr className="w-full h-14 border-b">
                    <td className="w-1/5">patient</td>
                    <td className="w-1/5">responsable</td>
                    <td className="w-1/5">motif</td>
                    <td className="w-1/5 text-center">lieu</td>
                    <td className="w-[10%] text-center">oui/non</td>
                    <td className="w-[10%]">
                      <div className="w-full h-full flex justify-center items-start gap-5">
                        <button
                          type="button"
                          onClick={handleFormsDisplay}
                          className="p-2 text-blue-600 hover:text-zinc-100 hover:bg-blue-600 rounded-full"
                        >
                          <FaChevronRight />
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </>
        }
        displayForm={formsDisplay}
        forms={
          <>
            {formsDisplay ? (
              <button
                type="button"
                onClick={handleFormsDisplay}
                className="w-10 h-10 absolute top-16 left-full flex justify-center items-center text-black hover:text-red-600 lg:hidden "
              >
                <FaXmark />
              </button>
            ) : (
              <></>
            )}
            <HeadlessTabs
              tabListClasse="w-full h-fit flex justify-evenly mb-3"
              tabListItemClass="w-fit h-10 px-2 outline-none hover:underline"
              tabListItemClassSelected="text-blue-700 underline"
              tabListItemClassNotSelected=""
              tabList={["details", "demande"]}
              tabPanelsClasse="w-full h-fit p-5 bg-zinc-200 rounded-2xl shadow-md"
              tabPanelItemClass="w-full h-fit"
              tabPanels={[
                <TransfertForms acces={acces} news={false} readOnly={true} />,
                <TransfertForms acces={acces} news={true} readOnly={false} />,
              ]}
            />
          </>
        }
      />
    </>
  );
}

export default Transfert;
