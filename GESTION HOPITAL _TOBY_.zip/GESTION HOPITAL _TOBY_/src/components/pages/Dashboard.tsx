import { DashItemM0 } from "@/components";
import {
  dataDepartement,
  dataPatient,
  dataPersonnel,
  dataService,
  dataUser,
} from "@/utils";
import React from "react";

import { FaHospital, FaUserNurse, FaAmbulance, FaUser } from "react-icons/fa";
import { FaHospitalUser } from "react-icons/fa6";
function Dashboard() {
  return (
    <>
      <div className="w-full h-fit grid grid-cols-4 gap-5">
        <ul className="col-span-full w-full h-fit grid sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-5">
          <li className="w-full h-fit ">
            <DashItemM0
              icon={<FaUserNurse />}
              iconClass="bg-blue-100 text-blue-700"
              title="personnels"
              titleClasse="text-blue-700"
              count={dataPersonnel.length}
            />
          </li>
          <li className="w-full h-fit ">
            <DashItemM0
              icon={<FaHospitalUser />}
              iconClass="bg-green-100 text-green-700"
              title="patients"
              titleClasse="text-green-700"
              count={dataPatient.length}
            />
          </li>
          <li className="w-full h-fit ">
            <DashItemM0
              icon={<FaHospital />}
              iconClass="bg-yellow-100 text-yellow-700"
              title="departements"
              titleClasse="text-yellow-700"
              count={dataDepartement.length}
            />
          </li>
          <li className="w-full h-fit ">
            <DashItemM0
              icon={<FaAmbulance />}
              iconClass="bg-red-100 text-red-700"
              title="services"
              titleClasse="text-red-700"
              count={dataService.length}
            />
          </li>
          <li className="w-full h-fit ">
            <DashItemM0
              icon={<FaUser />}
              iconClass="bg-indigo-100 text-indigo-700"
              title="utilisateurs"
              titleClasse="text-indigo-700"
              count={dataUser.length}
            />
          </li>
        </ul>

        <div className="sm:col-span-full xl:col-span-3 w-full h-fit">
          <h6 className="underline text-blue-600 mb-2">
            <span className="">transfert recents</span>
          </h6>
          <table className="w-full max-w-full h-fit">
            <thead className="w-full h-fit text-zinc-600">
              <tr className="w-full h-fit">
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">patient</p>
                </td>
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">sante</p>
                </td>
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">personnel</p>
                </td>
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">lieu</p>
                </td>
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">date</p>
                </td>
              </tr>
            </thead>
            <tbody className="w-full h-fit">
              <tr className="w-full h-10 border-b hover:bg-zinc-300 cursor-pointer ">
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">kevin hart</p>
                </td>
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">malcroissance</p>
                </td>
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">jason statham</p>
                </td>
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">madagascar</p>
                </td>
                <td className="w-1/5 min-w-[20%] max-w-[20%]">
                  <p className="w-full truncate">23 oct 2023</p>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="sm:col-span-full xl:col-span-1 w-full h-fit ">
          <h6 className="col-span-full underline text-blue-600 flex justify-between mb-2">
            <span className="">personnels actifs</span>
          </h6>
          <ul className="w-full h-fit grid sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-1 gap-3 ">
            <li className="w-full h-fit p-2 flex items-start gap-2 hover:bg-zinc-300 cursor-pointer rounded-xl">
              <div className="w-12 h-12 min-w-[48px] min-h-[48px] max-h-[48px] bg-zinc-200 rounded-full relative "></div>
              <div className="w-full h-12 min-h-[48px] max-h-[48px] ">
                <h6 className="">nom</h6>
                <span className="text-green-600">poste</span>
              </div>
            </li>
            <li className="w-full h-fit p-2 flex items-start gap-2 hover:bg-zinc-300 cursor-pointer rounded-xl">
              <div className="w-12 h-12 min-w-[48px] min-h-[48px] max-h-[48px] bg-zinc-200 rounded-full relative "></div>
              <div className="w-full h-12 min-h-[48px] max-h-[48px] ">
                <h6 className="">nom</h6>
                <span className="text-green-600">poste</span>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
}

export default Dashboard;
