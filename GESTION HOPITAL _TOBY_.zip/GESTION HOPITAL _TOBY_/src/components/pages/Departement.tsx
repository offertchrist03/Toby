"use client";

import { DepartementForms } from "@/components";
import Pages from "@/components/fragments/Pages";
import HeadlessTabs from "@/components/headlessui/HeadlessTabs";
import { data, dataDepartement, dataPersonnel } from "@/utils";
import React, { useState } from "react";
import { FaChevronRight } from "react-icons/fa";
import { FaXmark } from "react-icons/fa6";

function Departement() {
  const [formsDisplay, setFormsDisplay] = useState(false);
  const handleFormsDisplay = () => {
    setFormsDisplay(!formsDisplay);
  };

  return (
    <>
      <Pages
        headClass="text-yellow-600 lowercase"
        head={
          <>
            departement existants : <span className="">15</span>
          </>
        }
        theadClass=""
        thead={
          <>
            <tr className="w-full h-10">
              <th className="min-w-[80px] text-zinc-700 underline">
                code departement
              </th>
              <th className="min-w-[80px] text-zinc-700 underline">
                designation
              </th>
              <th className="min-w-[80px] text-zinc-700 underline">
                personnels
              </th>
              <th className="min-w-[80px] text-zinc-700 underline">actifs</th>
              <th className="min-w-[50px] max-w-[50px] "></th>
            </tr>
          </>
        }
        tbodyClass="text-center"
        tbody={
          <>
            {dataDepartement.map((item) => (
              <tr className="w-full h-12 border-b " key={item.id_departement}>
                <td className="">{item.code_dep}</td>
                <td className=""> {item.designation}</td>
                <td className="">15</td>
                <td className="text-green-700">
                  {
                    dataPersonnel.map(
                      (data) => data.code_dep === item.code_dep && data,
                    ).length
                  }{" "}
                </td>
                <td className="">
                  <div className="w-full h-fit flex justify-center gap-5">
                    <button
                      type="button"
                      onClick={handleFormsDisplay}
                      className="p-2 text-blue-600 hover:text-zinc-100 hover:bg-blue-600 rounded-full"
                    >
                      <FaChevronRight />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </>
        }
        displayForm={formsDisplay}
        forms={
          <>
            {formsDisplay ? (
              <button
                type="button"
                onClick={handleFormsDisplay}
                className="w-10 h-10 absolute top-16 left-full flex justify-center items-center text-black hover:text-red-600 lg:hidden "
              >
                <FaXmark />
              </button>
            ) : (
              <></>
            )}
            <HeadlessTabs
              tabListClasse="w-full h-fit flex justify-evenly mb-3"
              tabListItemClass="w-fit h-10 px-2 outline-none hover:underline"
              tabListItemClassSelected="text-blue-700 underline"
              tabListItemClassNotSelected=""
              tabList={["details", "modification", "ajout"]}
              tabPanelsClasse="w-full h-fit p-5 bg-zinc-200 rounded-2xl shadow-md"
              tabPanelItemClass="w-full h-fit"
              tabPanels={[
                <DepartementForms news={false} readOnly={true} />,
                <DepartementForms news={false} readOnly={false} />,
                <DepartementForms news={true} readOnly={false} />,
              ]}
            />
          </>
        }
      />
    </>
  );
}

export default Departement;
