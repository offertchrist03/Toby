"use client";

import Pages from "@/components/fragments/Pages";
import { FaChevronRight } from "react-icons/fa";
import React, { useState } from "react";
import { HeadlessTabs, PatientForms } from "@/components";
import { FaXmark } from "react-icons/fa6";
import { dataPatient } from "@/utils";

function Patient() {
  const [formsDisplay, setFormsDisplay] = useState(false);
  const handleFormsDisplay = () => {
    setFormsDisplay(!formsDisplay);
  };

  return (
    <>
      <Pages
        headClass="text-green-700"
        head={
          <>
            total patient : <span className="">{dataPatient.length}</span>
          </>
        }
        theadClass=""
        thead={
          <>
            <tr className="w-full ">
              <td className="w-1/5 underline text-zinc-800 h-10">nom</td>
              <td className="w-1/5 underline text-zinc-800 h-10">prenom</td>
              <td className="w-[10%] underline text-zinc-800 h-10 text-center">
                age
              </td>
              <td className="w-1/5 underline text-zinc-800 h-10 text-center">
                nationalite
              </td>
              <td className="w-1/5 underline text-zinc-800 h-10">maladie</td>
              <td className="w-[10%] "></td>
            </tr>
          </>
        }
        tbodyClass=""
        tbody={
          <>
            {dataPatient.map((item) => (
              <tr className="w-full h-14 hover:bg-zinc-200  border-b">
                <td className="w-1/5 h-full py-2 min-h-[56px] ">
                  <p className="w-full h-full">{item.nom}</p>
                </td>
                <td className="w-1/5 h-full py-2 ">
                  <p className="w-full h-full">{item.prenon}</p>
                </td>
                <td className="w-[10%] h-full py-2 border-b text-center">
                  <p className="w-full h-full text-center">
                    {item.date_naissance}
                  </p>
                </td>
                <td className="w-1/5 h-full py-2 ">
                  <p className="w-full h-full text-center">
                    {item.nationnalite}
                  </p>
                </td>
                <td className="w-1/5 h-full py-2 ">
                  <p className="w-full h-full">{item.maladie}</p>
                </td>
                <td className="w-[10%] h-full py-2 border-b text-center">
                  <div className="w-full h-full flex justify-center items-start gap-5">
                    <button
                      type="button"
                      onClick={handleFormsDisplay}
                      className="p-2 text-blue-600 hover:text-zinc-100 hover:bg-blue-600 rounded-full"
                    >
                      <FaChevronRight />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </>
        }
        displayForm={formsDisplay}
        forms={
          <>
            {formsDisplay ? (
              <button
                type="button"
                onClick={handleFormsDisplay}
                className="w-10 h-10 absolute top-16 left-full flex justify-center items-center text-black hover:text-red-600 lg:hidden "
              >
                <FaXmark />
              </button>
            ) : (
              <></>
            )}
            <HeadlessTabs
              tabListClasse="w-full h-fit flex justify-evenly mb-3"
              tabListItemClass="w-fit h-10 px-2 outline-none hover:underline"
              tabListItemClassSelected="text-blue-700 underline"
              tabListItemClassNotSelected=""
              tabList={["details", "modification", "ajout"]}
              tabPanelsClasse="w-full h-fit p-5 bg-zinc-200 rounded-2xl shadow-md"
              tabPanelItemClass="w-full h-fit"
              tabPanels={[
                <PatientForms news={false} readOnly={true} />,
                <PatientForms news={false} readOnly={false} />,
                <PatientForms news={true} readOnly={false} />,
              ]}
            />
          </>
        }
      />
    </>
  );
}

export default Patient;
