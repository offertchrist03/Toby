"use client";

import { classNameFuseFilter } from "@/functions/usefullFunc";
import { HeadlessLinksProps } from "@/types";
import { Tab } from "@headlessui/react";

export default function HeadlessTabs({
  tabList,
  tabListClasse,
  tabListItemClass,
  tabListItemClassSelected,
  tabListItemClassNotSelected,
  tabPanels,
  tabPanelsClasse,
  tabPanelItemClass,
}: HeadlessLinksProps) {
  return (
    <>
      <Tab.Group>
        <Tab.List className={tabListClasse}>
          {tabList.map((item) => (
            <Tab
              className={({ selected }) =>
                classNameFuseFilter(
                  tabListItemClass,
                  selected
                    ? tabListItemClassSelected
                    : tabListItemClassNotSelected,
                )
              }
            >
              {item}
            </Tab>
          ))}
        </Tab.List>
        <Tab.Panels className={tabPanelsClasse}>
          {tabPanels.map((item) => (
            <Tab.Panel className={tabPanelItemClass}>{item}</Tab.Panel>
          ))}
        </Tab.Panels>
      </Tab.Group>
    </>
  );
}
