import React from "react";

function HeadlessAutocomplete() {
  return (
    <>
      <div>HeadlessAutocomplete</div>
    </>
  );
}

export default HeadlessAutocomplete;
