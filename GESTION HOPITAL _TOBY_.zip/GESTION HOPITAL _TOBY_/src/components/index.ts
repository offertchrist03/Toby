import IconContainerM0 from "./customs/IconContainerM0";

import DashItemM0 from "./fragments/DashItemM0";
import DepartementForms from "./fragments/DepartementForms";
import PatientForms from "./fragments/PatientForms";
import PersonnelForms from "./fragments/PersonnelForms";
import ServiceForms from "./fragments/ServiceForms";
import TransfertForms from "./fragments/TransfertForms";
import Pages from "./fragments/Pages";

import HeadlessTabs from "./headlessui/HeadlessTabs";

import Dashboard from "./pages/Dashboard";
import Departement from "./pages/Departement";
import Patient from "./pages/Patient";
import Personnel from "./pages/Personnel";
import Service from "./pages/Service";
import Transfert from "./pages/Transfert";
import PagesLayout from "./pages/PagesLayout";

export {
  IconContainerM0,
  DashItemM0,
  DepartementForms,
  PatientForms,
  PersonnelForms,
  ServiceForms,
  TransfertForms,
  Pages,
  HeadlessTabs,
  Dashboard,
  Departement,
  Patient,
  Personnel,
  Service,
  Transfert,
  PagesLayout,
};
