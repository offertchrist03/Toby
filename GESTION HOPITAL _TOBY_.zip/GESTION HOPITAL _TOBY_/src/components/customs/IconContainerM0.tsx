import { IconContainerM0Props } from "@/types";
import React from "react";

function IconContainerM0({ iconClass, icon }: IconContainerM0Props) {
  return (
    <>
      <div
        className={
          "w-20 min-w-[80px] h-20 rounded-full relative flex justify-center items-center text-3xl " +
          iconClass
        }
      >
        {icon}
      </div>
    </>
  );
}

export default IconContainerM0;
