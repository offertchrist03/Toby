function testTypeE(e) {
  const res = typeof e
  console.log('res', res)
}

export {testTypeE}