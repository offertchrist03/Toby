"use client";

import { classNameFuseFilter } from "@/functions/usefullFunc";
import { DepartementFormsProps } from "@/types";
import React, { useState } from "react";
import {
  FaAmbulance,
  FaCheck,
  FaHospital,
  FaHospitalAlt,
  FaRedo,
  FaSave,
  FaTrash,
  FaUndo,
} from "react-icons/fa";
import { IconContainerM0 } from "..";
import { PagesItemsIn, PagesNewInput } from "./PagesFormsInputs";

function DetailEdit(
  readOnly: boolean = false,
  type: "secours" | "urgence" = "urgence",
) {
  return (
    <>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("type", "type", readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("responsable", "responsable", readOnly)}
      </div>

      {type === "urgence" ? (
        <>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("patient", "patient", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("sante", "sante", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("traitement", "traitement", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("date entree", "date entree", readOnly)}
          </div>
        </>
      ) : (
        <>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("matriclue", "matriclue", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("marque", "marque", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("disponible", "disponible", readOnly)}
          </div>
        </>
      )}

      <div className="w-full flex justify-center gap-5">
        {readOnly ? (
          <>
            <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
              supprimer <FaTrash />
            </button>
          </>
        ) : (
          <>
            <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
              annuler <FaUndo />
            </button>
            <button className="w-fit h-10 text-zinc-50 bg-green-600 hover:bg-green-700 px-2 rounded-lg flex items-center gap-2">
              confirmer <FaCheck />
            </button>
          </>
        )}
      </div>
    </>
  );
}

function newAdd(type: "secours" | "urgence" = "urgence") {
  const [display, setdisplay] = useState<Boolean>(false);

  const handleDisplay = (): void => {
    setdisplay(!display);
  };

  return (
    <>
      <div className="w-full h-fit flex justify-center">
        <button
          type="button"
          className="w-fit h-10 px-2 bg-blue-700 hover:bg-blue-800 text-zinc-100 rounded"
          onClick={handleDisplay}
        >
          creer nouveau
        </button>
      </div>
      <div
        className={classNameFuseFilter(
          "w-full h-full fixed top-0 left-0 bg-zinc-100 flex-col items-center py-10 overflow-scroll z-10",
          display ? "flex" : "hidden",
        )}
      >
        <IconContainerM0
          iconClass="w-16 min-w-[64px] h-16 min-h-[64px] bg-red-200 text-2xl text-red-700 mx-auto mb-5 "
          icon={
            <>
              <FaAmbulance />
            </>
          }
        />
        <div className="w-full max-w-2xl h-fit grid grid-cols-2 gap-5">
          <h2 className="col-span-full text-center text-green-700">
            <span className="">nouveau service</span>
          </h2>
          {PagesNewInput("type")}
          {PagesNewInput("responsable")}
          {type === "urgence" ? (
            <>
              {PagesNewInput("patient")}
              {PagesNewInput("sante")}
              {PagesNewInput("traitement")}
            </>
          ) : (
            <>
              {PagesNewInput("matriclue")}
              {PagesNewInput("marque")}
              {PagesNewInput("disponible")}
            </>
          )}

          <div className="col-span-full w-full h-fit flex justify-center gap-5 mt-2">
            <button
              type="button"
              onClick={handleDisplay}
              className="w-fit min-w-[100px] h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex justify-center items-center gap-2"
            >
              annuler <FaUndo />
            </button>
            <button className="w-fit min-w-[100px] h-10 text-zinc-50 bg-blue-600 hover:bg-blue-700 px-2 rounded-lg flex justify-center items-center gap-2">
              creer <FaSave />
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function ServiceForms({ readOnly = false, news }: DepartementFormsProps) {
  return (
    <>
      <IconContainerM0
        iconClass="w-16 min-w-[64px] h-16 bg-red-200 text-2xl text-red-700 mx-auto mb-5 "
        icon={
          <>
            <FaAmbulance />
          </>
        }
      />

      {news ? <>{newAdd()}</> : <>{DetailEdit(readOnly)}</>}
    </>
  );
}

export default ServiceForms;
