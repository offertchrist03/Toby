import { DashItemProps } from "@/types";
import React from "react";

function DashItemM0({
  icon,
  iconClass,
  title,
  titleClasse,
  count,
  countClasse,
}: DashItemProps) {
  return (
    <>
      <div className="w-full h-fit rounded-2xl bg-zinc-50 shadow-md flex items-center p-5 gap-5">
        <div
          className={
            "sm:w-16 sm:min-w-[64px] sm:h-16w-16 sm:min-h-[64px] xl:w-20 xl:min-w-[80px] xl:h-20 xl:min-h-[80px] rounded-full relative flex justify-center items-center text-3xl " +
            iconClass
          }
        >
          {icon}
        </div>
        <div className="w-full sm:h-16 xl:h-20">
          <h5 className={`lowercase ${titleClasse}`}>{title}</h5>
          <h6 className={countClasse}>{count}</h6>
        </div>
      </div>
    </>
  );
}

export default DashItemM0;
