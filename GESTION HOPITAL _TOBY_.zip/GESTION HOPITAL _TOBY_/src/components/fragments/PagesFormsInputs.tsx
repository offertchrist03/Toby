import { classNameFuseFilter } from "@/functions/usefullFunc";

export function PagesItemsIn(
  label: string,
  value: string | number,
  readOnly: boolean = false,
) {
  return (
    <>
      <h6 className="sm:w-1/2 truncate md:w-full">{label}</h6>
      <input
        type="text"
        className={classNameFuseFilter(
          "w-full outline-none max-w-full ",
          readOnly ? "text-green-600 bg-transparent" : "bg-blue-100",
        )}
        readOnly={readOnly}
        value={value}
      />
    </>
  );
}

export function PagesNewInput(label: string) {
  return (
    <>
      <div className="">
        <label className="mb-1 block">{label}</label>
        <input
          type="text"
          className="w-full h-10 px-2 rounded focus:outline outline-2 outline-blue-600"
        />
      </div>
    </>
  );
}
