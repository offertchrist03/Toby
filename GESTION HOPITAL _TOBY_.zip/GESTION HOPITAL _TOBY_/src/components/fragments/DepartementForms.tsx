import { classNameFuseFilter } from "@/functions/usefullFunc";
import { DepartementFormsProps } from "@/types";
import React from "react";
import {
  FaCheck,
  FaHospital,
  FaHospitalAlt,
  FaRedo,
  FaSave,
  FaTrash,
  FaUndo,
} from "react-icons/fa";
import { IconContainerM0 } from "..";
import { PagesItemsIn, PagesNewInput } from "./PagesFormsInputs";

function DetailEdit(readOnly: boolean = false) {
  return (
    <>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("id departement", "id departement", readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("code departement", "code departement", readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("designation", "designation", readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("total personnels", 15, readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("personnels actifs", 12, readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("modifie le", "12/08/2023", readOnly)}
      </div>
      <div className="w-full flex justify-center gap-5">
        {readOnly ? (
          <>
            <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
              supprimer <FaTrash />
            </button>
          </>
        ) : (
          <>
            <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
              annuler <FaUndo />
            </button>
            <button className="w-fit h-10 text-zinc-50 bg-green-600 hover:bg-green-700 px-2 rounded-lg flex items-center gap-2">
              confirmer <FaCheck />
            </button>
          </>
        )}
      </div>
    </>
  );
}

function newAdd() {
  return (
    <>
      <div className="w-full h-fit flex flex-col gap-3">
        <h2 className="text-center text-green-700">
          <span className="">nouveau departement</span>
        </h2>
        {PagesNewInput("code departement")}
        {PagesNewInput("designation")}

        <div className="w-full h-fit flex justify-center gap-5 mt-2">
          <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
            annuler <FaUndo />
          </button>
          <button className="w-fit h-10 text-zinc-50 bg-blue-600 hover:bg-blue-700 px-2 rounded-lg flex items-center gap-2">
            creer <FaSave />
          </button>
        </div>
      </div>
    </>
  );
}

function DepartementForms({ readOnly = false, news }: DepartementFormsProps) {
  return (
    <>
      <IconContainerM0
        icon={
          <>
            <FaHospital />
          </>
        }
        iconClass="w-16 min-w-[64px] h-16 bg-yellow-200 text-2xl text-yellow-700 mx-auto mb-5 "
      />

      {news ? <>{newAdd()}</> : <>{DetailEdit(readOnly)}</>}
    </>
  );
}

export default DepartementForms;
