"use client";

import { classNameFuseFilter } from "@/functions/usefullFunc";
import { DepartementFormsProps } from "@/types";
import React, { useState } from "react";
import {
  FaHospitalSymbol,
  FaCheck,
  FaSave,
  FaTrash,
  FaUndo,
} from "react-icons/fa";
import { IconContainerM0 } from "..";
import { PagesItemsIn, PagesNewInput } from "./PagesFormsInputs";
import { FaXmark } from "react-icons/fa6";

function DetailEdit(
  acces: "admin" | "personnel",
  readOnly: boolean = false,
  demande: boolean = true,
) {
  return (
    <>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("id transfert", "id transfert", readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("patient", "patient", readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("responsable", "responsable", readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("motif", "motif", readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("lieu", "lieu", readOnly)}
      </div>
      <div className="h-10 flex items-baseline overflow-hidden gap-3">
        {PagesItemsIn("sante", "sante", readOnly)}
      </div>
      {demande ? (
        <>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("demandee le", "demandee le", readOnly)}
          </div>
        </>
      ) : (
        <>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("acceptee le", "acceptee le", readOnly)}
          </div>
        </>
      )}

      <div className="w-full flex justify-center gap-5">
        {acces === "admin" ? (
          <>
            {demande ? (
              <>
                <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
                  refuser <FaXmark />
                </button>
                <button className="w-fit h-10 text-zinc-50 bg-green-600 hover:bg-green-700 px-2 rounded-lg flex items-center gap-2">
                  accepter <FaCheck />
                </button>
              </>
            ) : (
              <>
                <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
                  supprimer <FaTrash />
                </button>
              </>
            )}
          </>
        ) : (
          <>
            <>
              <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
                supprimer <FaTrash />
              </button>
            </>
          </>
        )}
      </div>
    </>
  );
}

function newAdd() {
  const [display, setdisplay] = useState<Boolean>(false);

  const handleDisplay = (): void => {
    setdisplay(!display);
  };

  return (
    <>
      <div className="w-full h-fit flex justify-center">
        <button
          type="button"
          className="w-fit h-10 px-2 bg-blue-700 hover:bg-blue-800 text-zinc-100 rounded-lg "
          onClick={handleDisplay}
        >
          nouvelle demande
        </button>
      </div>
      <div
        className={classNameFuseFilter(
          "w-full h-full fixed top-0 left-0 bg-zinc-100 flex-col items-center py-10 overflow-scroll z-10",
          display ? "flex" : "hidden",
        )}
      >
        <IconContainerM0
          iconClass="w-16 min-w-[64px] h-16 min-h-[64px] bg-indigo-200 text-2xl text-indigo-700 mx-auto mb-5 "
          icon={
            <>
              <FaHospitalSymbol />
            </>
          }
        />
        <div className="w-full max-w-2xl h-fit grid grid-cols-2 gap-5">
          <h2 className="col-span-full text-center text-green-700">
            <span className="">nouvelle demande</span>
          </h2>
          {PagesNewInput("id patient")}
          {PagesNewInput("id personnel responsable")}
          {PagesNewInput("motif")}
          {PagesNewInput("lieu")}
          {PagesNewInput("sante")}

          <div className="col-span-full w-full h-fit flex justify-center gap-5 mt-2">
            <button
              type="button"
              onClick={handleDisplay}
              className="w-fit min-w-[100px] h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex justify-center items-center gap-2"
            >
              annuler <FaUndo />
            </button>
            <button className="w-fit min-w-[100px] h-10 text-zinc-50 bg-blue-600 hover:bg-blue-700 px-2 rounded-lg flex justify-center items-center gap-2">
              soumettre demande <FaSave />
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function TransfertForms({
  readOnly = false,
  news,
  acces,
}: DepartementFormsProps) {
  return (
    <>
      <IconContainerM0
        iconClass="w-16 min-w-[64px] h-16 bg-indigo-200 text-2xl text-indigo-700 mx-auto mb-5 "
        icon={
          <>
            <FaHospitalSymbol />
          </>
        }
      />

      {news ? <>{newAdd()}</> : <>{DetailEdit(acces, readOnly)}</>}
    </>
  );
}

export default TransfertForms;
