"use client";

import { classNameFuseFilter } from "@/functions/usefullFunc";
import { PagesProps } from "@/types";
import React, { useEffect, useState } from "react";
import { FaXmark } from "react-icons/fa6";

function Pages({
  headContainerClass,
  head,
  headClass,
  thead,
  theadClass,
  tbody,
  tbodyClass,
  forms,
  displayForm,
  contents,
}: PagesProps) {
  const [formsDisplay, setFormsDisplay] = useState(displayForm);
  // const handleFormsDisplay = () => {
  //   setFormsDisplay(false);
  // };

  useEffect(() => {
    setFormsDisplay(displayForm);
  }, [displayForm]);

  return (
    <>
      <div className="w-full h-fit grid grid-cols-6 gap-5">
        <div className="col-span-full lg:col-span-4 ">
          <div className={`w-full h-fit mb-2 ${headContainerClass}`}>
            <div className={headClass}>{head}</div>
            <div className="w-1/2 bg-zinc-200 p-2 rounded-xl">recherche</div>
          </div>

          <table className="w-full h-fit ">
            <thead className={`w-full h-fit ${theadClass}`}>{thead}</thead>
            <tbody className={`${tbodyClass}`}>{tbody}</tbody>
          </table>

          {contents}
        </div>

        <div
          className={classNameFuseFilter(
            "col-span-2 w-full lg:h-fit lg:relative flex lg:block",
            formsDisplay
              ? "md:h-full md:fixed top-0 left-0 justify-center md:p-10 lg:p-0 md:bg-zinc-50 lg:bg-transparent overflow-auto"
              : "hidden bg-transparent",
          )}
        >
          <div className="w-full max-w-sm h-fit relative ">{forms}</div>
        </div>
      </div>
    </>
  );
}

export default Pages;
