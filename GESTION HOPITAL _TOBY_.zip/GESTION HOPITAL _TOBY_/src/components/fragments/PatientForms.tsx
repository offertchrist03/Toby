"use client";

import React, { useState } from "react";
import { PagesItemsIn, PagesNewInput } from "./PagesFormsInputs";

import {
  FaArrowLeft,
  FaCheck,
  FaHospital,
  FaHospitalAlt,
  FaPlusCircle,
  FaRedo,
  FaSave,
  FaTrash,
  FaUndo,
} from "react-icons/fa";
import { FaDeleteLeft, FaHospitalUser, FaX } from "react-icons/fa6";

import { DepartementFormsProps } from "@/types";
import { IconContainerM0 } from "..";
import { classNameFuseFilter } from "@/functions/usefullFunc";

function DetailEdit(readOnly: boolean = false) {
  const [display, setdisplay] = useState<Boolean>(false);

  const handleDisplay = (): void => {
    setdisplay(!display);
  };

  return (
    <>
      <div className="w-full h-fit">
        <div className="h-10 flex items-baseline overflow-hidden gap-3">
          {PagesItemsIn("id", "id", readOnly)}
        </div>
        <div className="h-10 flex items-baseline overflow-hidden gap-3">
          {PagesItemsIn("nom", "nom", readOnly)}
        </div>
        <div className="h-10 flex items-baseline overflow-hidden gap-3">
          {PagesItemsIn("prenom", "prenom", readOnly)}
        </div>
        <div className="h-10 flex items-baseline overflow-hidden gap-3">
          {PagesItemsIn("age", 19, readOnly)}
        </div>
        <div className="h-10 flex items-baseline overflow-hidden gap-3">
          {PagesItemsIn("contact", "0330201244", readOnly)}
        </div>
        <div className="h-10 flex items-baseline overflow-hidden gap-3">
          {PagesItemsIn("nationalite", "malagasy", readOnly)}
        </div>
        <div className="h-10 flex items-baseline overflow-hidden gap-3">
          {PagesItemsIn("maladie", "maladie", readOnly)}
        </div>
        <div className="h-10 flex items-baseline overflow-hidden gap-3">
          {PagesItemsIn("entree le", "date", readOnly)}
        </div>
      </div>

      <div
        className={classNameFuseFilter(
          "w-full h-full fixed top-0 left-0 bg-zinc-100 flex-col items-center py-10 overflow-scroll z-10",
          display ? "flex" : "hidden",
        )}
      >
        <IconContainerM0
          iconClass="w-16 min-w-[64px] h-16 min-h-[64px] bg-green-200 text-2xl text-green-700 mx-auto mb-5 "
          icon={
            <>
              <FaHospitalUser />
            </>
          }
        />

        <div className="w-full max-w-5xl h-fit grid grid-cols-3 gap-5">
          <h2 className="col-span-full text-center text-blue-600">
            {readOnly ? "details patient" : "modifier patient"}
          </h2>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("id", "id", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("nom", "nom", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("prenom", "prenom", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("naissance", "12/08/2004", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("age", 19, readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("adresse", "chez toi", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("contact", "0330201244", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("email", "patient@gmail.com", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("nationalite", "malagasy", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("maladie", "maladie", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("nom de famille", "nom de famille", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("contact famille", "contact famille", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("adresse famille", "adresse famille", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("entree le", "date", readOnly)}
          </div>
          <div className="h-10 flex items-baseline overflow-hidden gap-3">
            {PagesItemsIn("modifie le", "12/08/2023", true)}
          </div>

          <div className="col-span-full w-full h-fit flex justify-center gap-5">
            <button
              type="button"
              className="w-fit h-10 px-2 bg-yellow-500 hover:bg-yellow-600 text-black rounded-lg flex items-center gap-2"
              onClick={handleDisplay}
            >
              retour <FaArrowLeft />
            </button>

            {readOnly ? (
              <>
                <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
                  supprimer <FaTrash />
                </button>
              </>
            ) : (
              <>
                <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
                  annuler <FaX />
                </button>
                <button className="w-fit h-10 text-zinc-50 bg-green-600 hover:bg-green-700 px-2 rounded-lg flex items-center gap-2">
                  confirmer <FaCheck />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
      <div className="w-full flex justify-center gap-5">
        <button
          type="button"
          className="w-fit h-10 px-2 bg-blue-700 hover:bg-blue-800 text-zinc-100 rounded-lg flex items-center gap-2"
          onClick={handleDisplay}
        >
          plus <FaPlusCircle />
        </button>
        {readOnly ? (
          <>
            <button className="w-fit h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex items-center gap-2">
              supprimer <FaTrash />
            </button>
          </>
        ) : (
          <>
            <button className="w-fit h-10 text-zinc-50 bg-green-600 hover:bg-green-700 px-2 rounded-lg flex items-center gap-2">
              confirmer <FaCheck />
            </button>
          </>
        )}
      </div>
    </>
  );
}

function newAdd() {
  const [display, setdisplay] = useState<Boolean>(false);

  const handleDisplay = (): void => {
    setdisplay(!display);
  };

  return (
    <>
      <div className="w-full h-fit flex justify-center">
        <button
          type="button"
          className="w-fit h-10 px-2 bg-blue-700 hover:bg-blue-800 text-zinc-100 rounded"
          onClick={handleDisplay}
        >
          creer nouveau
        </button>
      </div>
      <div
        className={classNameFuseFilter(
          "w-full h-full fixed top-0 left-0 bg-zinc-100 flex-col items-center py-10 overflow-scroll z-10",
          display ? "flex" : "hidden",
        )}
      >
        <IconContainerM0
          iconClass="w-16 min-w-[64px] h-16 min-h-[64px] bg-green-200 text-2xl text-green-700 mx-auto mb-5 "
          icon={
            <>
              <FaHospitalUser />
            </>
          }
        />
        <div className="w-full max-w-5xl h-fit grid grid-cols-3 gap-5">
          <h2 className="col-span-full text-center text-green-700">
            <span className="">nouveau patient</span>
          </h2>
          {PagesNewInput("nom")}
          {PagesNewInput("prenom")}
          {PagesNewInput("naissance")}
          {PagesNewInput("adresse")}
          {PagesNewInput("contact")}
          {PagesNewInput("email")}
          {PagesNewInput("nationalite")}
          {PagesNewInput("maladie")}
          {PagesNewInput("nom de famille")}
          {PagesNewInput("contact famille")}
          {PagesNewInput("adresse famille")}

          <div className="col-span-full w-full h-fit flex justify-center gap-5 mt-2">
            <button
              type="button"
              onClick={handleDisplay}
              className="w-fit min-w-[100px] h-10 text-zinc-50 bg-red-600 hover:bg-red-700 px-2 rounded-lg flex justify-center items-center gap-2"
            >
              annuler <FaUndo />
            </button>
            <button className="w-fit min-w-[100px] h-10 text-zinc-50 bg-blue-600 hover:bg-blue-700 px-2 rounded-lg flex justify-center items-center gap-2">
              creer <FaSave />
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function PatientForms({ readOnly = false, news }: DepartementFormsProps) {
  return (
    <>
      <IconContainerM0
        iconClass="w-16 min-w-[64px] h-16 bg-green-200 text-2xl text-green-700 mx-auto mb-5 "
        icon={
          <>
            <FaHospitalUser />
          </>
        }
      />

      {news ? <>{newAdd()}</> : <>{DetailEdit(readOnly)}</>}
    </>
  );
}

export default PatientForms;
