export interface PersonnelProps {
  matricule: string;
  nom: string;
  prenom: string;
  telephone: number;
  email: string;
  cin: string;
  poste: string;
  date_embauche: string;
  code_dep: string;
  photo: string;
}

export interface PatientProps {
  nom: string;
  prenon: string;
  date_naissance: string;
  adresse: string;
  telephone: number;
  email: string;
  nationnalite: string;
  maladie: string;
  nom_famille: string;
  telephone_famille: string;
  adresse_famille: string;
  date_entree: string;
  photo: string;
}

export interface ServiceUrgenceProps {
  id_patient: string;
  sante: string;
  traitement: string;
  date_entree: string;
  date_sortie: string;
}

export interface ServiceProps {
  matricule: string;
  disponibilite: string;
  marque: string;
  id_personnel: string;
}

export interface DepartementProps {
  code_dep: string;
  designation: string;
}

export interface TransfertProps {
  id_transfert: string;
  id_patient: string;
  id_personnel: string;
  motif: string;
  lieu: string;
  sante: string;
}

export interface AuthProps {
  identifiant: string;
  passe: string;
}
