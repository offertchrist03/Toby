import React, { MouseEvent, MouseEventHandler } from "react";

export interface AccesProps {
  acces: "admin" | "personnel";
}

// HEADLESSUI
export interface HeadlessLinksProps {
  tabList: React.ReactNode[];
  tabListClasse: string;
  tabListItemClass: string;
  tabListItemClassSelected: string;
  tabListItemClassNotSelected: string;
  tabPanels: React.ReactNode[];
  tabPanelsClasse?: string;
  tabPanelItemClass?: string;
}
// HEADLESSUI

export interface CustomLinkProps {
  key: string;
  icon: React.ReactNode;
  title: string;
  link: string;
}

// FRAGMENT
export interface DashItemProps {
  icon: React.ReactNode;
  iconClass?: string;
  title: string;
  titleClasse?: string;
  count: number;
  countClasse?: string;
}

export interface PagesProps {
  headContainerClass?: string;
  head: React.ReactNode;
  headClass: string;
  thead?: React.ReactNode;
  theadClass?: string;
  tbody?: React.ReactNode;
  tbodyClass?: string;
  forms: React.ReactNode;
  displayForm: boolean;
  contents?: React.ReactNode;
}
// FRAGMENT

// DEPARTEMENT
export interface DepartementFormsProps {
  readOnly: boolean;
  news: boolean;
  acces?: "admin" | "personnel";
}
// DEPARTEMENT

// CUSTOM
export interface IconContainerM0Props {
  iconClass: string;
  icon: React.ReactNode;
}
// CUSTOM
